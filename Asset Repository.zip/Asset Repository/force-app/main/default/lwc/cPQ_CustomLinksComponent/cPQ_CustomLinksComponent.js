/********************************************************************* 
Name : CPQ_CustomLinksComponent
Author : Christian Kildal-Brandt
Date : 2/24/2023
Usage : Lightning Web Component used to dynamically render external and dynamic links held in custom metadata records depending on the header specified in the LWC parameters and the users permission sets

Dependencies : CPQ_CustomLinks (Apex Class), Custom Metadata (Custom_Links_Header__mdt, Custom_Links_Item__mdt)
History: (Modified entry should be made for any substantial change, if you are not sure, create an entry)
Modified: <date of modification> - <developer or group responsible> (Used on first modification)
Comment : <description of modification including bug tracking ID or Jira>
*/

import { api, LightningElement, wire } from 'lwc';
import fetchLinkItems from '@salesforce/apex/CPQ_CustomLinks.fetchLinkItems';
import fetchLinkHeader from '@salesforce/apex/CPQ_CustomLinks.fetchLinkHeader';

export default class CPQ_CustomLinksComponent extends LightningElement {
@api recordId;
// set as 'does not exist' as the objectApiName returns either undefined or a String (will break wired apex class if value is undefined)
@api objectApiName = 'does not exist';
@api props;
@api icon;
wiredLinkItems;
error;
title = 'No Link Header';
hidden;

@wire( fetchLinkHeader, { props: '$props' })
fetchLinkHeaderFunction ({ error, data }){
    if(data){
        this.error = undefined;
        this.title = data.Display_header__c;
        this.hidden = data.Hide_Component__c;
    }else if(error){
        this.error = error;
    }
}

@wire( fetchLinkItems, { props: '$props', context: '$objectApiName' })
fetchLinkItemFunction ({ error, data }){
    if(data){
        this.error = undefined;
        console.log('data', data);
        const copiedLinkItems = [...data];
        let val = 0
        // loops through returned links and dynamically replaces {recordId} value on links with the record id that the user is clicking from
        for(const d of copiedLinkItems){
            if (d.URL__c.includes('{recordId}')) {
                const tempObj = {...copiedLinkItems[val]};
                tempObj.URL__c = copiedLinkItems[val].URL__c.replace('{recordId}', this.recordId);
                copiedLinkItems.splice(val, 1, tempObj);
            }
            val++
        }
        this.wiredLinkItems = copiedLinkItems;
    }else if(error){
        this.error = error;
    }
}
}